//
//  submityourrequestVC.swift
//  itLabMachineTest
//
//  Created by Sonu_Gupta on 02/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class submityourrequestVC: UIViewController, UITextViewDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate {
    @IBOutlet weak var informationTextView: UITextView!
    @IBOutlet weak var submitbtn: UIButton!
    @IBOutlet weak var yourrequiestTableview: UITableView!
    @IBOutlet weak var staffingView: UIView!
    @IBOutlet weak var camraBtn: UIButton!
     @IBOutlet weak var staffingBtn: UIButton!
    @IBOutlet weak var profileimageView: UIImageView!
    @IBOutlet weak var maleBtn: UIButton!
    @IBOutlet weak var femaleBtn: UIButton!
    @IBOutlet weak var doesntmatterBtn: UIButton!
    @IBOutlet weak var inhomeBtn: UIButton!
    @IBOutlet weak var communityBtn: UIButton!
    @IBOutlet weak var bothBtn: UIButton!
    
    
    var strarray = ["Job Title*","Agency Name*","Contact Person*","Agency Phone Number*","Company Address"]
     var placeholderarray = ["Job Title","Agency Name","Contact Person","Agency Phone Number","Address line 1"]
    var placeholderaddarray = ["Address line 2","City","State","Zip Code"]
    var stiffingarray = ["Immediately","After two week","After two days","Tommorow"]
     var imagePicker = UIImagePickerController()
    var obj = submitrequestModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        yourrequiestTableview.delegate = self
        yourrequiestTableview.dataSource = self
        submitbtn.layer.cornerRadius = 25
        maleBtn.layer.cornerRadius = 22.5
        femaleBtn.layer.cornerRadius = 22.5
        doesntmatterBtn.layer.cornerRadius = 22.5
        inhomeBtn.layer.cornerRadius = 22.5
        communityBtn.layer.cornerRadius = 22.5
        bothBtn.layer.cornerRadius = 22.5
        
        staffingView.layer.cornerRadius = 10
        staffingView.layer.borderWidth = 0.4
        staffingView.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
        
        informationTextView.layer.cornerRadius = 10
        informationTextView.layer.borderWidth = 0.4
        informationTextView.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
        
        informationTextView.text = "Please share about the job"
        informationTextView.textColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
        informationTextView.returnKeyType = .done
        informationTextView.delegate = self
        staffingBtn.addTarget(self, action:#selector(stiffingbtnTapped), for: .touchUpInside)
        
    }
    
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if informationTextView.text == "Please share about the job" {
            informationTextView.text = ""
            informationTextView.textColor =  UIColor.black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if informationTextView.text == "" {
            
            informationTextView.text = "Please share about the job"
            informationTextView.textColor =  UIColor.white
        }
        func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
            
            if text == "\n" {
                
                informationTextView.resignFirstResponder()
                
            }
            
            return true
            
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
     
                let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
                profileimageView.image = image
               picker.dismiss(animated: true, completion: nil)
    
       }
       
       func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
           picker.dismiss(animated: true, completion: nil)
         }
    
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
        {
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
            
        }
        else
        {
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary()
    {
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
        
    }
    
    @objc func stiffingbtnTapped(_ sender: UIButton) {
    
         RPicker.selectOption(dataArray: stiffingarray) { (selctedText, atIndex) in
            self.obj.staffing = selctedText
            self.staffingBtn.setTitle(self.obj.staffing, for: .normal)
            self.yourrequiestTableview.reloadData()
            
             
         }
    }
    
    @IBAction func camraBtnTapped(_ sender: UIButton) {
       
        imagePicker.delegate = self
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
                    alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
                    self.openCamera()
                     }))
                     alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
                     self.openGallary()
                     }))
                     alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
                     self.present(alert, animated: true, completion: nil)
    }
    @IBAction func closebtnTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }

    @IBAction func malebtnTapped(_ sender: Any) {
           maleBtn.backgroundColor = #colorLiteral(red: 0.7333333333, green: 0.8745098039, blue: 1, alpha: 1)
           femaleBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
           doesntmatterBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
           yourrequiestTableview.reloadData()
       }
    @IBAction func femalebtnTapped(_ sender: Any) {
             femaleBtn.backgroundColor = #colorLiteral(red: 0.7333333333, green: 0.8745098039, blue: 1, alpha: 1)
             doesntmatterBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
             maleBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
             yourrequiestTableview.reloadData()
         }
    @IBAction func doesntmatterbtnTapped(_ sender: Any) {
             femaleBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
             doesntmatterBtn.backgroundColor = #colorLiteral(red: 0.7333333333, green: 0.8745098039, blue: 1, alpha: 1)
             maleBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
             yourrequiestTableview.reloadData()
         }
    
    
    @IBAction func inhomebtntapped(_ sender: Any) {
        inhomeBtn.backgroundColor = #colorLiteral(red: 0.7333333333, green: 0.8745098039, blue: 1, alpha: 1)
        communityBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
        bothBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
        yourrequiestTableview.reloadData()
    }
    @IBAction func communitybtnTapped(_ sender: Any) {
           inhomeBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
           communityBtn.backgroundColor = #colorLiteral(red: 0.7333333333, green: 0.8745098039, blue: 1, alpha: 1)
           bothBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
           yourrequiestTableview.reloadData()
       }
    @IBAction func bothbtnTapped(_ sender: Any) {
           inhomeBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
           communityBtn.backgroundColor = #colorLiteral(red: 0.937254902, green: 0.937254902, blue: 0.937254902, alpha: 1)
           bothBtn.backgroundColor = #colorLiteral(red: 0.7333333333, green: 0.8745098039, blue: 1, alpha: 1)
           yourrequiestTableview.reloadData()
       }
    @IBAction func submitbtnTapped(_ sender: Any) {
        if validateallFields() == true{
            
        }
        
    }
}


//MARK: - UITableview Datasource and delegate Action

extension submityourrequestVC: UITableViewDataSource, UITableViewDelegate {
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return placeholderarray.count + 5
}
func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    switch indexPath.row {
    case 0:
         let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "submitrequesttextfiledTVCell", for: indexPath) as! submitrequesttextfiledTVCell
                yourrequiest.titleLbl.text = strarray[indexPath.row]
                yourrequiest.commonTextfiled.placeholder = placeholderarray[indexPath.row]
         yourrequiest.commonTextfiled.tag = 100
         yourrequiest.commonTextfiled.tag = indexPath.row + 100
         yourrequiest.commonTextfiled.delegate = self
         yourrequiest.commonTextfiled.text = obj.jobtitle
         yourrequiest.errorLbl.text = (indexPath.row == obj.errorIndex ? obj.strErrorMsg : "")
              return yourrequiest
    case 1:
            let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "submitrequesttextfiledTVCell", for: indexPath) as! submitrequesttextfiledTVCell
                   yourrequiest.titleLbl.text = strarray[indexPath.row]
                   yourrequiest.commonTextfiled.placeholder = placeholderarray[indexPath.row]
            yourrequiest.commonTextfiled.tag = 100
            yourrequiest.commonTextfiled.tag = indexPath.row + 100
            yourrequiest.commonTextfiled.delegate = self
            yourrequiest.commonTextfiled.text = obj.agencyname
            yourrequiest.errorLbl.text = (indexPath.row == obj.errorIndex ? obj.strErrorMsg : "")
                 return yourrequiest
        case 2:
                let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "submitrequesttextfiledTVCell", for: indexPath) as! submitrequesttextfiledTVCell
                       yourrequiest.titleLbl.text = strarray[indexPath.row]
                       yourrequiest.commonTextfiled.placeholder = placeholderarray[indexPath.row]
                yourrequiest.commonTextfiled.tag = 100
                yourrequiest.commonTextfiled.tag = indexPath.row + 100
                yourrequiest.commonTextfiled.delegate = self
                yourrequiest.commonTextfiled.text = obj.contactperson
                yourrequiest.errorLbl.text = (indexPath.row == obj.errorIndex ? obj.strErrorMsg : "")
                     return yourrequiest
        case 3:
                let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "submitrequesttextfiledTVCell", for: indexPath) as! submitrequesttextfiledTVCell
                       yourrequiest.titleLbl.text = strarray[indexPath.row]
                       yourrequiest.commonTextfiled.placeholder = placeholderarray[indexPath.row]
                yourrequiest.commonTextfiled.tag = 100
                yourrequiest.commonTextfiled.tag = indexPath.row + 100
                yourrequiest.commonTextfiled.delegate = self
                yourrequiest.commonTextfiled.text = obj.agencyphonenumber
                yourrequiest.errorLbl.text = (indexPath.row == obj.errorIndex ? obj.strErrorMsg : "")
                yourrequiest.commonTextfiled.keyboardType = .phonePad
                     return yourrequiest
        case 4:
                let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "submitrequesttextfiledTVCell", for: indexPath) as! submitrequesttextfiledTVCell
                       yourrequiest.titleLbl.text = strarray[indexPath.row]
                       yourrequiest.commonTextfiled.placeholder = placeholderarray[indexPath.row]
                yourrequiest.commonTextfiled.tag = 100
                yourrequiest.commonTextfiled.tag = indexPath.row + 100
                yourrequiest.commonTextfiled.delegate = self
                yourrequiest.commonTextfiled.text = obj.companyaddress
                yourrequiest.errorLbl.text = (indexPath.row == obj.errorIndex ? obj.strErrorMsg : "")
                     return yourrequiest
    case 5:
                let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "SubmitreqaddresstableviewCell", for: indexPath) as! SubmitreqaddresstableviewCell
                       yourrequiest.commonTextfiled.placeholder = placeholderaddarray[indexPath.row - 5]
                     return yourrequiest
        case 6:
        let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "SubmitreqaddresstableviewCell", for: indexPath) as! SubmitreqaddresstableviewCell
               yourrequiest.commonTextfiled.placeholder = placeholderaddarray[indexPath.row - 5]
             return yourrequiest
        case 7:
        let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "SubmitreqaddresstableviewCell", for: indexPath) as! SubmitreqaddresstableviewCell
               yourrequiest.commonTextfiled.placeholder = placeholderaddarray[indexPath.row - 5]
             return yourrequiest
        case 8:
        let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "SubmitreqaddresstableviewCell", for: indexPath) as! SubmitreqaddresstableviewCell
               yourrequiest.commonTextfiled.placeholder = placeholderaddarray[indexPath.row - 5]
        yourrequiest.commonTextfiled.keyboardType = .phonePad
             return yourrequiest
        case 9:
        let yourrequiest = tableView.dequeueReusableCell(withIdentifier: "submitrequesttextfiledTVCell", for: indexPath) as! submitrequesttextfiledTVCell
               yourrequiest.titleLbl.text = "Email Address:"//strarray[indexPath.row - 9]
               yourrequiest.commonTextfiled.placeholder = "Email Address:"//placeholderarray[indexPath.row - 9]
        yourrequiest.commonTextfiled.keyboardType = .emailAddress
             return yourrequiest
    default:
        break
    }
    return UITableViewCell()
      
    
}

}


 extension submityourrequestVC : UITextFieldDelegate {
 func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String)-> Bool{
     if let text = textField.text as NSString? {
         
         let newstring = text.replacingCharacters(in: range, with: string)
         let numofchar = newstring.count
        
        switch textField.tag - 100{
             
         case 0:
             obj.jobtitle = newstring
             if numofchar > 20 || (textField.textInputMode?.primaryLanguage == "emoji") {
                 return false
             }
             if range.location == 0 && (string == " ") {
                 return false
             }
             else {
                
                 let allOverChar = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")
                 let characterSet = CharacterSet(charactersIn: string)
                 if numofchar == 0 || numofchar == 1 {
                    
                let cell : submitrequesttextfiledTVCell = (yourrequiestTableview.cellForRow(at: IndexPath(row: 0, section: 0)) as? submitrequesttextfiledTVCell)!
                cell.errorLbl.text = "Please enter your job title."
                 }
                else {
                    
                let cell : submitrequesttextfiledTVCell = (yourrequiestTableview.cellForRow(at: IndexPath(row: 0, section: 0)) as? submitrequesttextfiledTVCell)!
                cell.errorLbl.text = ""
                 }
             return allOverChar.isSuperset(of: characterSet)
             }
         case 1:
            obj.agencyname = newstring
             if numofchar > 20 || (textField.textInputMode?.primaryLanguage == "emoji")
             {
                 return false
             }
             if range.location == 0 && (string == " "){
                 return false
             }
             else {
                
                 let allOverChar = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ")
                 let characterSet = CharacterSet(charactersIn: string)
                 if numofchar == 1 || numofchar == 0 {
                     let cell : submitrequesttextfiledTVCell = (yourrequiestTableview.cellForRow(at: IndexPath(row: 1, section: 0)) as? submitrequesttextfiledTVCell)!
                     cell.errorLbl.text = "*Please enter your agency name."
                 }
                 
                 else {
                     let cell : submitrequesttextfiledTVCell = (yourrequiestTableview.cellForRow(at: IndexPath(row: 1, section: 0)) as? submitrequesttextfiledTVCell)!
                     cell.errorLbl.text = ""
                 }
                 
                 return allOverChar.isSuperset(of: characterSet)
             }
         
         case 2:
            
            obj.contactperson = newstring
            if let cell : submitrequesttextfiledTVCell = yourrequiestTableview.cellForRow(at: IndexPath(row: 2, section: 0)) as? submitrequesttextfiledTVCell {
                if(obj.errorIndex == 2){
                    cell.errorLbl.text = obj.strErrorMsg
                }
                        else if (numofchar < 8)
                    {
                       cell.errorLbl.text = "*Please enter contact person."
                    }
                    else {
                    cell.errorLbl.text = ""
                }
            }
            return true
        case 3:
            obj.agencyphonenumber = newstring
            if numofchar > 20 || (textField.textInputMode?.primaryLanguage == "emoji")
            {
                return false
            }
             if let cell : submitrequesttextfiledTVCell = yourrequiestTableview.cellForRow(at: IndexPath(row: 2, section: 0)) as? submitrequesttextfiledTVCell {
                if(obj.errorIndex == 3){
    
                       cell.errorLbl.text = obj.strErrorMsg
                       } else if (numofchar < 10)
                       {
                       cell.errorLbl.text = "*Please enter your agency phonenumber."
                       }
                       else if (numofchar == 50){
                       return false
                           
                       }
            }
          case 4:
            obj.companyaddress = newstring
                                  
            if let cell : submitrequesttextfiledTVCell = yourrequiestTableview.cellForRow(at: IndexPath(row: 3, section: 0)) as? submitrequesttextfiledTVCell
                                       
                {
            if(obj.errorIndex == 4){
            cell.errorLbl.text = obj.strErrorMsg
            } else if (numofchar < 10)
            {
            cell.errorLbl.text = "*Please enter your company address."
            }
            else if (numofchar == 12){
            return false
                
            }
           else {
          cell.errorLbl.text = ""
           }
            }
        return true
            default:
                        return true
            }
             }
                
        
        return true
   
}
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
               if textField.returnKeyType == .next {
                   let nexttextfield = self.view.viewWithTag(textField.tag + 1) as! UITextField
                   nexttextfield.becomeFirstResponder()
                   
               }
               else{
                   textField.resignFirstResponder()
               }
               return true
           }
    }


extension submityourrequestVC {
    
    func validateallFields() -> Bool {
        var isValid = false
        if (obj.jobtitle.isEmpty)
        {
            obj.errorIndex = 0
            obj.strErrorMsg = "*Please enter your jobtitle."
            self.yourrequiestTableview.scrollToRow(at : IndexPath(row: 0, section: 0), at: .top, animated: true)
            
        }
            
        else if (obj.agencyname.isEmpty){
            
            obj.errorIndex = 1
            obj.strErrorMsg = "*Please enter your agency name."
            self.yourrequiestTableview.scrollToRow(at : IndexPath(row: 1, section: 0), at: .top, animated: true)
            
        }
            
        else if (obj.contactperson.isEmpty){
            obj.errorIndex = 2
            obj.strErrorMsg = "*Please enter your contact person."
            self.yourrequiestTableview.scrollToRow(at : IndexPath(row: 2, section: 0), at: .top, animated: true)
        }
        else if obj.agencyphonenumber.isEmpty{
                     
            obj.errorIndex = 3
            obj.strErrorMsg = "*Please enter your agency phonenumber."
            self.yourrequiestTableview.scrollToRow(at : IndexPath(row: 3, section: 0), at: .top, animated: true)
                     
            }
        else if (obj.companyaddress.isEmpty){
            
            obj.errorIndex = 4
            obj.strErrorMsg = "*Please enter your comapny address."
            self.yourrequiestTableview.scrollToRow(at : IndexPath(row: 4, section: 0), at: .top, animated: true)
        }
  
        else{
            isValid = true

        }
        self.yourrequiestTableview.reloadData()
       return isValid
       
    }
    
}

//MARK:- SignUpVC Modal
class submitrequestModel : NSObject {
   var strErrorMsg = ""
    var errorIndex = -1
    var jobtitle = ""
    var agencyname = ""
    var stremail = ""
    var contactperson = ""
    var agencyphonenumber = ""
    var companyaddress = ""
    var staffing = "Immediately"

}
