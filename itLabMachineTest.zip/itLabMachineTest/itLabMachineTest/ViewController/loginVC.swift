//
//  loginVC.swift
//  itLabMachineTest
//
//  Created by Sonu_Gupta on 01/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class loginVC: UIViewController {
    @IBOutlet weak var signintableView: UITableView!
    @IBOutlet weak var signinButton: UIButton!
    @IBOutlet weak var emailtextfieldbackView: UIView!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var emailtextField: UITextField!
    @IBOutlet weak var emailerrorLbl: UILabel!
    @IBOutlet weak var passwordtextfieldbackView: UIView!
    @IBOutlet weak var passwordTextfiled: UITextField!
    @IBOutlet weak var passworderrorLbl: UILabel!
    
    var obj = signInModal()
    override func viewDidLoad() {
        super.viewDidLoad()
        emailtextField.tag = 100
        passwordTextfiled.tag = 101
        self.emailtextField.delegate = self
        self.passwordTextfiled.delegate = self
        backView.layer.cornerRadius = 5
        backView.layer.borderWidth = 0.4
        backView.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
        
        emailtextfieldbackView.layer.cornerRadius = 10
        emailtextfieldbackView.layer.borderWidth = 0.4
        emailtextfieldbackView.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
        
        passwordtextfieldbackView.layer.cornerRadius = 10
        passwordtextfieldbackView.layer.borderWidth = 0.4
        passwordtextfieldbackView.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
        signinButton.layer.cornerRadius = 25
        emailtextField.keyboardType = .emailAddress
    }
    
    @IBAction func signinBtnAction(_ sender: UIButton) {

        if validateAllFields() == true{
            let yourrecentrequiest = storyboard?.instantiateViewController(identifier: "recentrequestsVC") as! recentrequestsVC
            self.navigationController?.pushViewController(yourrecentrequiest, animated: true)
        }

    }
    
    @IBAction func signUpBtnAction(_ sender: UIButton) {

          let yourrecentrequiest = storyboard?.instantiateViewController(identifier: "signupVC") as! signupVC
          self.navigationController?.pushViewController(yourrecentrequiest, animated: true)

       }

}


//MARK: - Validation Funtion
extension loginVC {
    func validateAllFields() -> Bool {

        var isValid = false
        if emailtextField.text == "" {
           emailerrorLbl.text = "Please enter your email address."
        }
        else if passwordTextfiled.text == ""{
            emailerrorLbl.text = ""
            passworderrorLbl.text = "please enter your password."
        }

        else{
            passworderrorLbl.text = ""
            isValid = true
        }
   self.signintableView.reloadData()

        return isValid

    }

}


//MARK:- loginVC Modal
class signInModal : NSObject {
  var strErrorMsg = ""
    var errorIndex = -1
    var stremail = ""
    var strPassword = ""

}


//MARK: - UITextField delegate
extension loginVC : UITextFieldDelegate {
 func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String)-> Bool{
     if let text = textField.text as NSString? {
         
         let newstring = text.replacingCharacters(in: range, with: string)
         let numofchar = newstring.count
        
        switch textField.tag - 100{
         case 0:
            obj.stremail = newstring
            _ = isAllFieldForEmail()
                if (obj.errorIndex == 0){
                    emailerrorLbl.text = "Please enter your email email address."
                }
                        else if (numofchar < 15)
                    {
                        emailerrorLbl.text = "Please enter valid email address."
                    }
                    else {
                   emailerrorLbl.text = ""
                }
            case 1:
            obj.strPassword = newstring
            if numofchar > 30 || (textField.textInputMode?.primaryLanguage == "emoji") {
                return false
            }
            if range.location == 0 && (string == " ") {
                return false
            }
            else {
                if numofchar == 0 || numofchar == 1 {
                   
              passworderrorLbl.text = "Please enter your password."
                }
                else if numofchar <= 9 {
                                      
              passworderrorLbl.text = "Please enter your valid password."
             }
               else {
                passworderrorLbl.text = ""
                }
            }
           
            return true

     
            default:
                        return true
            }

            }
        return true
   
}
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
               if textField.returnKeyType == .next {
                   let nexttextfield = self.view.viewWithTag(textField.tag + 1) as! UITextField
                   nexttextfield.becomeFirstResponder()
                   
               }
               else{
                   textField.resignFirstResponder()
               }
               return true
           }
    }

extension loginVC {
    
    func isAllFieldForEmail() -> Bool {
        var isVerified = false
        
        if obj.stremail.count == 0 {
            
            emailerrorLbl.text = "*Please enter your email address."
        }
        else {
            isVerified = true
            obj.errorIndex = -1
            emailerrorLbl.text = ""
            let isValid = isValidEmail(testStr: obj.stremail)
            if isValid {
               
            } else {
                isVerified = false
                obj.errorIndex = 1
                emailerrorLbl.text = "*Please enter your correct email address."
            }
        }
        
       // self.TableView.reloadData()
        return isVerified
    }
    func isValidEmail(testStr:String) -> Bool {
      
        let emailRegEx = "^(((([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])+(\\.([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])+)*)|((\\x22)((((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(([\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]|\\x21|[\\x23-\\x5b]|[\\x5d-\\x7e]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(\\([\\x01-\\x09\\x0b\\x0c\\x0d-\\x7f]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}]))))*(((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(\\x22)))@((([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])([a-zA-Z]|\\d|-|\\.|_|~|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])*([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])))\\.)+(([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])([a-zA-Z]|\\d|-|_|~|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])*([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])))\\.?$"
        let email = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = email.evaluate(with: testStr)
        return result
    }
  
   
}

