//
//  recentrequestsVC.swift
//  itLabMachineTest
//
//  Created by Sonu_Gupta on 02/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class recentrequestsVC: UIViewController {
    @IBOutlet weak var bellBtn: UIButton!
    @IBOutlet weak var userBtn: UIButton!
    @IBOutlet weak var menuBtn: UIButton!
    @IBOutlet weak var recentyrequiestbackView: UIView!
    @IBOutlet weak var searchbackView: UIView!
    
    var strarray = ["Accepted","In Progress","Accepted","Close","Accepted" ]
    var strdoctor = ["Medical Doctor","Medical Nurse","Medical Doctor","Assistant","Medical Doctor" ]
    var strgender = ["Male","Female","male","Female","Male"]
     let imgarray = [UIImage(named: "doctor"), UIImage(named: "nurses"), UIImage(named: "doctor2"), UIImage(named: "assistent"),UIImage(named: "doctor2")]

    override func viewDidLoad() {
        super.viewDidLoad()

       searchbackView.layer.cornerRadius = 8
       searchbackView.layer.borderWidth = 0.4
       searchbackView.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
        
        menuBtn.layer.cornerRadius = 8
        menuBtn.layer.borderWidth = 0.4
        menuBtn.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
        
        
        
        recentyrequiestbackView.layer.shadowColor = UIColor.lightGray.cgColor
        recentyrequiestbackView.layer.shadowOpacity = 0.7
        recentyrequiestbackView.layer.shadowOffset = .zero
        recentyrequiestbackView.layer.shadowRadius = 5
        recentyrequiestbackView.layer.shadowPath = UIBezierPath(rect: recentyrequiestbackView.bounds).cgPath
        userBtn.clipsToBounds = true
        userBtn.layer.cornerRadius = userBtn.frame.width/2
    }
    

    @IBAction func plusbtnTapped(_ sender: Any) {
        
        let yourrecentrequiest = storyboard?.instantiateViewController(identifier: "submityourrequestVC") as! submityourrequestVC
          yourrecentrequiest.modalPresentationStyle = .fullScreen
       //  self.navigationController?.pushViewController(yourrecentrequiest, animated: true)
        self.present(yourrecentrequiest, animated: true, completion: nil)
    }
    

}


//MARK: - UITableview Datasource and delegate Action

extension recentrequestsVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
           return 80
           
       }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
           let headerCell = tableView.dequeueReusableCell(withIdentifier: "recentrequestfoorterTVCell") as! recentrequestfoorterTVCell
         
          return headerCell
      }
    
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return strarray.count
}
    

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
   
       let recentrequiest = tableView.dequeueReusableCell(withIdentifier: "recentrequestesTVCell", for: indexPath) as! recentrequestesTVCell
       
       recentrequiest.modelbl.text = strarray[indexPath.row]
       recentrequiest.doctortypeLbl.text = strdoctor[indexPath.row]
    recentrequiest.commonimageView.image = imgarray[indexPath.row]
       recentrequiest.genderlbl.text = strgender[indexPath.row]
    
    
    if recentrequiest.modelbl.text == "Accepted"{
        recentrequiest.modelbl.textColor = #colorLiteral(red: 0.231372549, green: 0.6470588235, blue: 0.4156862745, alpha: 1)
        recentrequiest.modelbl.backgroundColor = #colorLiteral(red: 0.8431372549, green: 0.9490196078, blue: 0.8862745098, alpha: 1)
    }
    else if recentrequiest.modelbl.text == "In Progress" {
         recentrequiest.modelbl.textColor = #colorLiteral(red: 0.9764705882, green: 0.6470588235, blue: 0.4156862745, alpha: 1)
        recentrequiest.modelbl.backgroundColor = #colorLiteral(red: 0.9960784314, green: 0.9176470588, blue: 0.8705882353, alpha: 1)
    }
    
    else if recentrequiest.modelbl.text == "Close" {
         recentrequiest.modelbl.textColor = #colorLiteral(red: 0.9333333333, green: 0.4039215686, blue: 0.4, alpha: 1)
        recentrequiest.modelbl.backgroundColor = #colorLiteral(red: 0.9803921569, green: 0.7254901961, blue: 0.7098039216, alpha: 1)
    }
     if recentrequiest.genderlbl.text == "Male"{
        recentrequiest.genderlbl.backgroundColor = #colorLiteral(red: 0.5098039216, green: 0.7058823529, blue: 1, alpha: 1)
    }
    else if recentrequiest.genderlbl.text == "Female"{
        recentrequiest.genderlbl.backgroundColor = #colorLiteral(red: 1, green: 0.4745098039, blue: 0.6352941176, alpha: 1)
    }
    
    
       return recentrequiest
    
}

}
