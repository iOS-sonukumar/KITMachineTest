//
//  signupVC.swift
//  itLabMachineTest
//
//  Created by Sonu_Gupta on 02/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class signupVC: UIViewController {
    
   @IBOutlet weak var signupTbaleview: UITableView!
    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var backView: UIView!
    var placeholderarray = ["First name","Last name","Email","Password"]
    var obj = signUpModal()
    override func viewDidLoad() {
        super.viewDidLoad()
        signupTbaleview.delegate = self
        signupTbaleview.dataSource = self
        signUpBtn.layer.cornerRadius = 25
//        backView.layer.cornerRadius = 10
//        backView.layer.borderWidth = 0.4
//        backView.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
      
    }
    
    override func viewDidAppear(_ animated: Bool) {
            // addTopAndBottomBorders()
          }
//    func addTopAndBottomBorders() {
//        let thickness: CGFloat = 0.4
//       let topBorder = CALayer()
//        let leadingBorder = CALayer()
//       topBorder.frame = CGRect(x: 0.0, y: 0.0, width: self.backView.frame.size.width, height: thickness)
//       topBorder.backgroundColor = #colorLiteral(red: 0.6, green: 0.6, blue: 0.6, alpha: 0.6014822346)
//        leadingBorder.frame = CGRect(x:0, y: self.backView.frame.size.height - thickness, width: self.backView.frame.size.width, height:thickness)
//        leadingBorder.backgroundColor = #colorLiteral(red: 0.6, green: 0.6, blue: 0.6, alpha: 0.6014822346)
//       backView.layer.addSublayer(topBorder)
//        backView.layer.addSublayer(leadingBorder)
//    }
    
    @IBAction func signUpBtnAction(_ sender: UIButton) {

          if validateallFields() == true{
//              let yourrecentrequiest = storyboard?.instantiateViewController(identifier: "recentrequestsVC") as! recentrequestsVC
//              self.navigationController?.pushViewController(yourrecentrequiest, animated: true)
          }

      }
    
       @IBAction func loginBtnAction(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
          }
    

}
//MARK: - UITableview Datasource and delegate Action

extension signupVC: UITableViewDataSource, UITableViewDelegate {
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return 4
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    switch indexPath.row {
    case 0:
         let signup = tableView.dequeueReusableCell(withIdentifier: "signupTVCell", for: indexPath) as! signupTVCell
         signup.commontextField.placeholder = placeholderarray[indexPath.row]
         signup.commontextField.tag = 100
         signup.commontextField.tag = indexPath.row + 100
         signup.commontextField.autocapitalizationType = .words
         signup.commontextField.delegate = self
         signup.commontextField.text = obj.strfirstname
         signup.errorLbl.text = (indexPath.row == obj.errorIndex ? obj.strErrorMsg : "")
              return signup
        case 1:
        let signup = tableView.dequeueReusableCell(withIdentifier: "signupTVCell", for: indexPath) as! signupTVCell
        signup.commontextField.placeholder = placeholderarray[indexPath.row]
        signup.commontextField.tag = 100
        signup.commontextField.tag = indexPath.row + 100
        signup.commontextField.autocapitalizationType = .words
        signup.commontextField.delegate = self
        signup.commontextField.text = obj.strlastname
        signup.errorLbl.text = (indexPath.row == obj.errorIndex ? obj.strErrorMsg : "")
             return signup
        case 2:
        let signup = tableView.dequeueReusableCell(withIdentifier: "signupTVCell", for: indexPath) as! signupTVCell
          signup.commontextField.placeholder = placeholderarray[indexPath.row]
        signup.commontextField.tag = 100
        signup.commontextField.tag = indexPath.row + 100
        signup.commontextField.keyboardType = .emailAddress
        signup.commontextField.delegate = self
        signup.commontextField.text = obj.stremail
        signup.errorLbl.text = (indexPath.row == obj.errorIndex ? obj.strErrorMsg : "")
             return signup
        case 3:
        let signup = tableView.dequeueReusableCell(withIdentifier: "signupTVCell", for: indexPath) as! signupTVCell
          signup.commontextField.placeholder = placeholderarray[indexPath.row]
        signup.commontextField.tag = 100
        signup.commontextField.tag = indexPath.row + 100
        signup.commontextField.isSecureTextEntry = true
        signup.commontextField.delegate = self
        signup.commontextField.text = obj.strPassword
        signup.errorLbl.text = (indexPath.row == obj.errorIndex ? obj.strErrorMsg : "")
             return signup
    default:
        break
    }
    return UITableViewCell()
   
      
    
}

}
 extension signupVC : UITextFieldDelegate {
 func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String)-> Bool{
     if let text = textField.text as NSString? {
         
         let newstring = text.replacingCharacters(in: range, with: string)
         let numofchar = newstring.count
        
        switch textField.tag - 100{
             
         case 0:
             obj.strfirstname = newstring
             if numofchar > 16 || (textField.textInputMode?.primaryLanguage == "emoji") {
                 return false
             }
             if range.location == 0 && (string == " ") {
                 return false
             }
             else {
                
                 let allOverChar = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")
                 let characterSet = CharacterSet(charactersIn: string)
                 if numofchar == 0 || numofchar == 1 {
                    
                let cell : signupTVCell = (signupTbaleview.cellForRow(at: IndexPath(row: 0, section: 0)) as? signupTVCell)!
                cell.errorLbl.text = "Please enter your first name."
                 }
                else {
                    
                let cell : signupTVCell = (signupTbaleview.cellForRow(at: IndexPath(row: 0, section: 0)) as? signupTVCell)!
                cell.errorLbl.text = ""
                 }
             return allOverChar.isSuperset(of: characterSet)
             }
         case 1:
            obj.strlastname = newstring
             if numofchar > 20 || (textField.textInputMode?.primaryLanguage == "emoji")
             {
                 return false
             }
             if range.location == 0 && (string == " "){
                 return false
             }
             else {
                
                 let allOverChar = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ")
                 let characterSet = CharacterSet(charactersIn: string)
                 if numofchar == 1 || numofchar == 0 {
                     let cell : signupTVCell = (signupTbaleview.cellForRow(at: IndexPath(row: 1, section: 0)) as? signupTVCell)!
                     cell.errorLbl.text = "*Please enter your last name."
                 }
                 
                 else {
                     let cell : signupTVCell = (signupTbaleview.cellForRow(at: IndexPath(row: 1, section: 0)) as? signupTVCell)!
                     cell.errorLbl.text = ""
                 }
                 
                 return allOverChar.isSuperset(of: characterSet)
             }
         
         case 2:
            
            obj.stremail = newstring
            _ = isAllFieldForEmail()
            if let cell : signupTVCell = signupTbaleview.cellForRow(at: IndexPath(row: 2, section: 0)) as? signupTVCell {
                if(obj.errorIndex == 2){
                    cell.errorLbl.text = obj.strErrorMsg
                }
                        else if (numofchar < 8)
                    {
                       cell.errorLbl.text = "*Please enter valid email address."
                    }
                    else {
                    cell.errorLbl.text = ""
                }
            }
            return true
          case 3:
            obj.strPassword = newstring
                                  
            if let cell : signupTVCell = signupTbaleview.cellForRow(at: IndexPath(row: 3, section: 0)) as? signupTVCell
                                       
                {
            if(obj.errorIndex == 3){
            cell.errorLbl.text = obj.strErrorMsg
            } else if (numofchar < 6)
            {
            cell.errorLbl.text = "*Please enter your password more than 6-digits."
            }
            else if (numofchar == 12){
            return false
                
            }
           else {
          cell.errorLbl.text = ""
           }
            }
        return true
            default:
                        return true
            }
             }
                
        
        return true
   
}
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
               if textField.returnKeyType == .next {
                   let nexttextfield = self.view.viewWithTag(textField.tag + 1) as! UITextField
                   nexttextfield.becomeFirstResponder()
                   
               }
               else{
                   textField.resignFirstResponder()
               }
               return true
           }
    }




extension signupVC {
    
    func validateallFields() -> Bool {
        var isValid = false
        if (obj.strfirstname.isEmpty)
        {
            obj.errorIndex = 0
            obj.strErrorMsg = "*Please enter your first name."
            self.signupTbaleview.scrollToRow(at : IndexPath(row: 0, section: 0), at: .top, animated: true)
            
        }
            
        else if (obj.strlastname.isEmpty){
            
            obj.errorIndex = 1
            obj.strErrorMsg = "*Please enter your last name."
            self.signupTbaleview.scrollToRow(at : IndexPath(row: 1, section: 0), at: .top, animated: true)
            
        }
            
        else if (obj.stremail.isEmpty){
            obj.errorIndex = 2
            obj.strErrorMsg = "*Please enter your e-mail address."
            self.signupTbaleview.scrollToRow(at : IndexPath(row: 2, section: 0), at: .top, animated: true)
        }
        else if (!isAllFieldForEmail()){
                     
            obj.errorIndex = 2
            obj.strErrorMsg = "*Please enter your valid email address."
            self.signupTbaleview.scrollToRow(at : IndexPath(row: 2, section: 0), at: .top, animated: true)
                     
            }
        else if (obj.strPassword.isEmpty){
            
            obj.errorIndex = 3
            obj.strErrorMsg = "*Please enter password."
            self.signupTbaleview.scrollToRow(at : IndexPath(row: 3, section: 0), at: .top, animated: true)
        }
  
         
         
        else{
            isValid = true

        }
        self.signupTbaleview.reloadData()
       return isValid
       
    }
    
}


extension signupVC {
    
    func isAllFieldForEmail() -> Bool {
        var isVerified = false
        
        if obj.stremail.count == 0 {
            
            obj.errorIndex = 2
            obj.strErrorMsg = "*Please enter your email address."
        }
        else {
            isVerified = true
            obj.errorIndex = -1
            obj.strErrorMsg = ""
            let isValid = isValidEmail(testStr: obj.stremail)
            if isValid {
               
            } else {
                isVerified = false
               
                obj.errorIndex = 2
            
                obj.strErrorMsg = "*Please enter your correct email address."
            }
        }
        
       // self.TableView.reloadData()
        return isVerified
    }
    func isValidEmail(testStr:String) -> Bool {
      
        let emailRegEx = "^(((([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])+(\\.([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])+)*)|((\\x22)((((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(([\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]|\\x21|[\\x23-\\x5b]|[\\x5d-\\x7e]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(\\([\\x01-\\x09\\x0b\\x0c\\x0d-\\x7f]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}]))))*(((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(\\x22)))@((([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])([a-zA-Z]|\\d|-|\\.|_|~|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])*([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])))\\.)+(([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])([a-zA-Z]|\\d|-|_|~|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])*([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])))\\.?$"
        let email = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = email.evaluate(with: testStr)
        return result
    }
    
    func isContainsAllZeros(testStr: String) -> Bool {
        
        
        let mobileNoRegEx = "^0{2,15}$"
        
        let mobileNoTest = NSPredicate(format: "SELF MATCHES %@", mobileNoRegEx)
        
        return mobileNoTest.evaluate(with: testStr)
        
    }
}

//MARK:- loginVC Modal
class signUpModal : NSObject {
  var strErrorMsg = ""
    var errorIndex = -1
    var stremail = ""
    var strPassword = ""
    var strfirstname = ""
    var strlastname = ""

}
