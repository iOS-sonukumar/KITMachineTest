//
//  submitrequesttextfiledTVCell.swift
//  itLabMachineTest
//
//  Created by Sonu_Gupta on 02/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class submitrequesttextfiledTVCell: UITableViewCell {

    @IBOutlet weak var textfieldbackView: UIView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var commonTextfiled: UITextField!
    @IBOutlet weak var errorLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        textfieldbackView.layer.cornerRadius = 10
        textfieldbackView.layer.borderWidth = 0.4
        textfieldbackView.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

}
