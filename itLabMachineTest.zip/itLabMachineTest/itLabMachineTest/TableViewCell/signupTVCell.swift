//
//  signupTVCell.swift
//  itLabMachineTest
//
//  Created by Sonu_Gupta on 02/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class signupTVCell: UITableViewCell {
    @IBOutlet weak var commontextField: UITextField!
    @IBOutlet weak var errorLbl: UILabel!
    @IBOutlet weak var textfieldbackVie: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
         textfieldbackVie.layer.cornerRadius = 10
         textfieldbackVie.layer.borderWidth = 0.4
         textfieldbackVie.layer.borderColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 0.6000107021)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
