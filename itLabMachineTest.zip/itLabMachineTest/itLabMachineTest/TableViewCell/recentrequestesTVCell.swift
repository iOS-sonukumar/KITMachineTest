//
//  recentrequestesTVCell.swift
//  itLabMachineTest
//
//  Created by Sonu_Gupta on 02/03/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class recentrequestesTVCell: UITableViewCell {
   @IBOutlet weak var modelbl: UILabel!
   @IBOutlet weak var backView: UIView!
    @IBOutlet weak var doctortypeLbl: UILabel!
    @IBOutlet weak var genderlbl: UILabel!
    @IBOutlet weak var commonimageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        backView.layer.cornerRadius = 8
        modelbl.clipsToBounds = true
        modelbl.layer.cornerRadius = 12.5
         genderlbl.clipsToBounds = true
        genderlbl.layer.cornerRadius = 12.5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
